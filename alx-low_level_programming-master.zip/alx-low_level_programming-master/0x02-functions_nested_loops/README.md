1. file 0 - 0-putchar.c- It prints out putchar

2. File 1-alphabet.c is a function that prints the alphabet, in lowercase, followed by a new line.

3. File 2-print_alphabet_x10.c\is a function that prints 10 times the alphabet, in lowercase, followed by a new line.

4. File 3-islower.cis a function that checks for lowercase character.

5. File 4-isalpha.c is a function that checks for alphabetic character.

6. File 5-sign.c is a function that prints the sign of a number.

7. File 6-abs.c is a function that computes the absolute value of an integer.

8. File 7-print_last_digit.cis a function that prints the last digit of a number.

9. File 8-24_hours.c is a function that prints every minute of the day of Jack Bauer, starting from 00:00 to 23:59.

10. File 10-add.c is a function that adds two integers and returns the result.

11. File 11-print_to_98.cis a function that prints all natural numbers from n to 98, followed by a new line.

12. File 100-times_table.c is a function that prints the n times table, starting with 0.

13. File 101-natural.c is a program that computes and prints the sum of all the multiples of 3 or 5 below 1024 (excluded), followed by a new line.

14. File 102-fibonacci.c is a program that prints the first 50 Fibonacci numbers, starting with 1 and 2, followed by a new line.

15. File 103-fibonacci.c is a program that finds and prints the sum of the even-valued terms of the Fibonacci suite under 4000000, followed by a new line.

16. File 104-fibonacci.c is a program that finds and prints the first 98 Fibonacci numbers, starting with 1 and 2, followed by a new line.

_putchar.c contains the _putchar() function definition.

main.h is the header file containing all the function prototypes used in this project.
