#ifndef MAIN_H
#define MAIN_H

int _putchar(char c);
int main(int _attribute_((_unused_)) argc, char *argv[]);
int main(int argc, char _attribute_((_unused_)) *argv[]);
int main(int argc, char *argv[]);
int main(int argc, char *argv[]);
int main(int argc, char *argv[]);
int main(int argc, char *argv[]);


#endif
