File 0-memset.c is a function that fills memory with a constant byte.

File 1-memcpy.c is a function that copies memory area.

File 2-strchr.c is a function that locates a character in a string.

File 3-strspn.c is a function that gets the length of a prefix substring.

File 4-strpbrk.c is a function that searches a string for any of a set of bytes.

File 5-strstr.c is a function that locates a substring.

File 7-print_chessboard.c is a function that prints the chessboard.

File 8-print_diagsums.c is a function that prints the sum of the two diagonals of a square matrix of integers.

File 100-set_string.c is a function that sets the value of a pointer to a char.

Fie 101- a file that contains the password for the crackme2 executable.

F
