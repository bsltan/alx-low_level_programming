#include "main.h"

/**
 * mul - Multiply two values
 * @a: First value
 * @b: Second value
 *
 * Return: result of a*b.
 */
int mul(int a, int b)
{
	int c = a * b;

	return (c);
}
