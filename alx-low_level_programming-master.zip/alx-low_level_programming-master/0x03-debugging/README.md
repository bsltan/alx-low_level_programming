C programming debugging
0-main.c, main.h
