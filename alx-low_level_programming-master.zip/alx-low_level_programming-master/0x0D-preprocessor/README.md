Understanding C program Compilation Process
