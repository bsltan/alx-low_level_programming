#include <stdio.h>

/**
 * main - print name of of this source file
 *
 * Return: Always 0.
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
